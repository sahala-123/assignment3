district_lists= [{'id': 1, 'name': 'Kannur'}, {'id': 2, 'name': 'Malappuram'}, {'id': 3, 'name': 'Kollam'}, {'id': 4,
'name': 'Alappuzha'}, {'id': 5, 'name': 'Kottayam'}]
